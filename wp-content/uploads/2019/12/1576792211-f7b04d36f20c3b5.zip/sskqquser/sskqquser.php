<?php

/*
Plugin Name: QQ信息自动获取系统
Plugin URI: http://ssk.91txh.com/
Description: 为你的网站添加免登陆QQ信息自动获取
Version: 1.0
Author: 搜索客
Author URI: http://ssk.91txh.com/
*/

?>
<?php
if ( !defined('ABSPATH') ) {exit;}
/* Set plugin path */
if ( !defined( 'SSK_DIR' ) ) {
	define( 'SSK_DIR', plugin_dir_path(__FILE__) );
}
/* Set plugin url */
if ( !defined( 'SSK_URI' ) ) {
	define( 'SSK_URI', plugin_dir_url(__FILE__) );
}
/* Set plugin version */
if ( !defined( 'SSK_VER' ) ) {
	define( 'SSK_VER', '1.0' );
}
/* Including functions */
require_once('functions.php');

function ssk_usermeta_table_install() {   
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . "ssk_usermeta";  //获取表前缀，并设置新表的名称
    if($wpdb->get_var("show tables like '{$table_name}'") != $table_name) {  //判断表是否已存在
        $sql = "CREATE TABLE {$table_name} (
		  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
          `uid` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
          `qq` bigint(20) UNSIGNED NOT NULL,
          `qqcheck` tinyint(1) NOT NULL DEFAULT '0',
          `email` varchar(100) NOT NULL,
          `emailcheck` tinyint(1) NOT NULL DEFAULT '0',
          `url` varchar(200) NOT NULL,
          `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`id`)
          ) {$charset_collate};";

        require_once(ABSPATH . "wp-admin/includes/upgrade.php");  //引用wordpress的内置方法库

        dbDelta($sql);
    }else{
    //echo "<script>alert('已安装');</script>";
    }
}
ssk_usermeta_table_install();

/* Add admin menu */
if( is_admin() ) {
    add_action('admin_menu', 'display_ssk_menu');
}
function display_ssk_menu() {
    add_menu_page('QQ用户中心', 'QQ用户中心', 'administrator','sskqquser', 'sskqquser','dashicons-groups');
}

/* Setting page html */
function sskqquser(){
    global $wpdb;
    $table_name=$wpdb->prefix."ssk_usermeta";
    $sql="SELECT * FROM `{$table_name}`";
    $result = object_array($wpdb->get_results($sql));
    //echo "<pre>";
    //print_r($result);
    //echo "</pre>";
    $count=count($result);
    //echo $count;
    $avatar="http://q.qlogo.cn/g?b=qq&nk=".$qq."&s=100&t=".time().generate_code();
	settings_errors();
	?>

<strong>
<p>QQ用户中心插件主页：<a href="http://ssk.91txh.com/381" target="_blank">http://ssk.91txh.com/381</a>&nbsp;&nbsp;&nbsp;&nbsp;QQ用户中心问题反馈：<a href="http://cn.mikecrm.com/JZgkvLO" target="_blank">http://cn.mikecrm.com/JZgkvLO</a></p>
</strong>

<table class="wp-list-table widefat fixed striped users" style="width:90% !important;">
    <thead>
        <tr>
            <th scope="col" id="username" class="manage-column column-username column-primary sorted desc">
                    <span>头像</span>
            </th>
            <th scope="col" id="name" class="manage-column column-name">用户名</th>
            <th scope="col" id="name" class="manage-column column-qq">QQ</th>
            <th scope="col" id="email" class="manage-column column-email sortable desc">
                    <span>电子邮件</span>
            </th>
            <th scope="col" id="role" class="manage-column column-role">角色</th>
    </thead>
    
    
    <tbody id="the-list" data-wp-lists="list:user">

<?php for($i=0;$i<$count;$i++){ ?>
    <tr id="user-<?php echo $i+1;?>">
            <td class="username column-username has-row-actions column-primary" data-colname="用户名">
                <img src="http://q.qlogo.cn/g?b=qq&nk=<?php echo $result[$i][qq]; ?>&s=100&t=<?php echo time().generate_code(); ?>" class="avatar avatar-64" height="64" width="64">
            </td>
            <td class="name column-name" data-colname="用户名">
                <strong>
                    <a href="<?php if($result[$i][url]!=""){echo $result[$i][url];}else{echo "javascript:void(0);";}; ?>"><?php echo sskqqname($result[$i][qq]); ?></a></strong>
            </td>
            <td class="name column-qq" data-colname="QQ">
                <strong>
                    <?php echo $result[$i][qq]; ?>
                </strong>
            </td>
            <td class="email column-email" data-colname="电子邮件">
                <a href="mailto:<?php echo $result[$i][email]; ?>"><?php echo $result[$i][email]; ?></a></td>
            <td class="role column-role" data-colname="角色"><?php if($result[$i][uid]==0){echo "游客";}else{echo "注册用户";}; ?></td>
        </tr>
<?php } ?>

    </tbody>
    
    
    <tfoot>
        <tr>
            <th scope="col" class="manage-column column-username column-primary sorted desc">
                    <span>头像</span>
            </th>
            <th scope="col" class="manage-column column-name">用户名</th>
            <th scope="col" class="manage-column column-qq">QQ</th>
            <th scope="col" class="manage-column column-email sortable desc">
                    <span>电子邮件</span>
            </th>
            <th scope="col" class="manage-column column-role">角色</th>
    </tfoot>
</table>
<?php

}
<?php
header("Content-Type:text/html; charset=UTF-8");
error_reporting(0);

include "../../../wp-load.php";
$table_name=$wpdb->prefix."ssk_usermeta";
    
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['type'])){
    if($_POST['type']=="qq"){
        if(isset($_POST['qq']) && $_POST['qq']==""){
            $message="请输入QQ";
            $status="1";
        }else{
            $qq=$_POST['qq'];
            $status="0";
        }
    }elseif($_POST['type']=="checkemail"){
        $qq=$_POST['qq'];
        $email=$_POST['email'];
        $status="0";
    }else{}

}else{
        $message="请求方式错误";
        $status="1";
}
//echo $qq;


$results = object_array($wpdb->get_results( "SELECT * FROM {$table_name} WHERE `qq` = {$qq}" ));
//echo "<pre>";
//print_r($results);
//echo "</pre>";
//echo count($results);//0为无记录，1为有记录
//echo $results[0][email];


$nameurl = "http://r.pengyou.com/fcg-bin/cgi_get_portrait.fcg?uins=".$qq;
$logourl="http://q.qlogo.cn/g?b=qq&nk={$qq}&s=100&t=".time().generate_code();
$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $nameurl); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
$contents = curl_exec($ch); 
curl_close($ch); 
$info=iconv('GBK', 'UTF-8', $contents);
//echo $contents;
$array = explode('"', $info);
//print_r($array);
//echo "<br>name:".$array[5]."<br>";
//echo "<br>logourl=".$logourl."<br>";
//echo "<img src='".$logourl."'>";

if($_POST['type']=="qq"){
    if(count($results)=="0"){
        $email=$qq."@qq.com";
        $url="";
    }else{
        $email=$results[0][email];
        $url=',"url":"'.$results[0][url].'"';
    }
}elseif($_POST['type']=="checkemail"){
    if(count($results)=="0"){
        //无此QQ
        $status="0";
    }else{
        //有QQ 判断有无新email记录
        $checkemail = object_array($wpdb->get_results( "SELECT * FROM {$table_name} WHERE `email` = '{$email}'" ));
        //echo "<pre>";
        //print_r($checkemail);
        //echo "</pre>";
        //echo count($checkemail);//0为无记录，1为有记录
        //echo $checkemail[0][email];
        if(count($checkemail)==0){
            //无记录 更新
            $status="0";
        }else{
            //有记录 判断QQ是否相同
            if($qq==$checkemail[0][qq]){
                $status="0";
            }else{
                $status="1";
                $message="邮箱已被占用！";
            }
        }

    }
}
if($_POST['type']=="qq"){
    if($status=="0"){
$cookiehash='' . COOKIEHASH;
print<<<END
{"name":"{$array[5]}","avatar":"{$logourl}","email":"{$email}"{$url},"status":"{$status}","cookiehash":"{$cookiehash}"}
END;
    }else{
print<<<END
{"message":"{$message}","status":"{$status}"}
END;
    }
}elseif($_POST['type']=="checkemail"){
    if($status=="0"){
print<<<END
{"status":"{$status}"}
END;
    }else{
print<<<END
{"message":"{$message}","status":"{$status}"}
END;
    }
}
?>
jQuery().ready(function() {
   var $=jQuery;
   var commentformavatar='#commentform div .avatar';//评论表单头像,本例为“<form……id="commentform"><div><img src="头像网址" class="avatar"></div></form>”，详见http://ssk.91txh.com/381
   var checkmailpos='.comment-form-email label';//请修改为您要添加邮件检测提示的位置
   var qqinputpos='.comment-form-url';//请修改为您要添加QQ输入框的位置
   var qqinput='<p class="comment-form-qq"><input id="qq" name="qq" type="text" value="" size="30" placeholder="输入QQ号码可以快速填写相关信息" /><label for="qq">QQ</label> <span id="loging"></span></p>';//请根据您的评论表单样式调整input和label的顺序，推荐 <span id="loging"></span> 接在 <label for="qq">QQ</label> 后面
   
   $(checkmailpos).after('<span id="checkemail"></span>');
   $(qqinputpos).after(qqinput);

   var i = 0, got = -1, len = document.getElementsByTagName('script').length;
while ( i <= len && got == -1){
	var js_url = document.getElementsByTagName('script')[i].src,
           got = js_url.indexOf('getqqinfo.js');
    i++ ;   
}
getqqinfo_url = js_url.replace('getqqinfo.js','qqinfo.php'),
//alert(getqqinfo_url);

   $("#qq").blur(function(){
        if($('#qq').val()!=""){
    $('#loging').html('<a style="font-size:12px;margin-left:5px;">\u6b63\u5728\u83b7\u53d6QQ\u4fe1\u606f..</a>');
     $.ajax({
        url: getqqinfo_url,
        type: "POST",
        data: {
            "type":"qq",
            "qq": $('#qq').val()
        },
        dataType: "json",
        success: function(qqinfo) {
            if(qqinfo.status==0){
                var unixTimestamp = new Date((Math.round(new Date().getTime()/1000)+30000000) * 1000);
                commonTime = unixTimestamp.toLocaleString();
                //alert(commonTime);
                $('#loging').html("");
                $('#checkemail').html("");
                $('#author').val(qqinfo.name);
                $('#email').val(qqinfo.email);
                $('#url').val(qqinfo.url);
                $(commentformavatar).attr("src",qqinfo.avatar);
                $.cookie('cookiehash', qqinfo.cookiehash, { expires: unixTimestamp});
                $.cookie('comment_author_qq_'+qqinfo.cookiehash, $('#qq').val(), { expires: unixTimestamp});
            }else{
                $('#loging').html("");
                alert(qqinfo.message);
            }
        }
    });
   }else{
       alert("请填写QQ！");
   }
})

$("#email").blur(function(){
    if($('#email').val()!=""){
if($('#qq').val()!=""){
    $('#checkemail').html('<a style="font-size:12px;margin-left:5px;">\u6b63\u5728\u83b7\u53d6\u4fe1\u606f..</a>');
    $.ajax({
        url: getqqinfo_url,
        type: "POST",
        data: {
            "type":"checkemail",
            "qq": $('#qq').val(),
            "email": $('#email').val()
        },
        dataType: "json",
        success: function(qqinfo) {
            if(qqinfo.status==0){
                $('#checkemail').html("此邮箱可用！");
            }else{
                $('#checkemail').html("此邮箱已被占用！");
                $('#email').val("");
            }
        }
    });
}else{
    //alert("请先填写QQ号！");
}
}else{
    $('#checkemail').html("请填写邮箱！");
}
})

if(!$.cookie('cookiehash')){
    //alert("无此cookie");
}else if($.cookie('cookiehash')!=""){
    //alert($.cookie('cookiehash'));
    var qq=$.cookie("comment_author_qq_"+$.cookie('cookiehash'));
    //alert($.cookie('cookiehash'));
    //alert(qq);
    $('#qq').val(qq);
}else{}
});
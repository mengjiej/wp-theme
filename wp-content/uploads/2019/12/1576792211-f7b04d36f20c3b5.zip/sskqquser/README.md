# ssk
QQ信息自动获取系统

# === QQ信息自动获取系统 ===
/*
Plugin Name: QQ信息自动获取系统
Plugin URI:http://ssk.91txh.com/381
Description:为你的网站添加免登陆QQ信息自动获取
Version: 1.0
Author: 搜索客
Author URI: http://ssk.91txh.com/
*/

# UPDATE

2017-03-13
1.0测试版正式上线
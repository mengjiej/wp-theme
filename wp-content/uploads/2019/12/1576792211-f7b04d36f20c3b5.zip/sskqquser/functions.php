<?php

/**
 * Main Functions of sskqquser WordPress Plugin
 *
 * @package   sskqquser
 * @version   1.0
 * @date      2017.3.13
 * @author    搜索客 <ssk@91txh.com>
 * @site      我的那些事 <ssk.91txh.com>
 * @copyright Copyright (c) 2017-2017, 搜索客
 * @license   http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link      http://ssk.91txh.com/381
**/

?>
<?php
/* Add JS and CSS */
function ssk_add_scripts() {
		$jq = SSK_URI.'static/jquery.min.js';
		wp_deregister_script( 'jquery' ); 
		wp_register_script( 'jquery', $jq ); 
		wp_enqueue_script( 'jquery' );
		$ssk_js = SSK_URI.'getqqinfo.js';
		wp_enqueue_script( 'ssk', $ssk_js, 'jquery', '', true );
        $ssk_cookie_js = SSK_URI.'static/jquery.cookie.js';
        wp_enqueue_script( 'ssk_cookie', $ssk_cookie_js, 'jquery', '', true );
	}
add_action('wp_enqueue_scripts', 'ssk_add_scripts');

function object_array($array) {  
//查询结果stdClass Object转array
    if(is_object($array)) {  
        $array = (array)$array;  
     } if(is_array($array)) {  
         foreach($array as $key=>$value) {  
             $array[$key] = object_array($value);  
             }  
     }  
     return $array;  
}

function generate_code($length = 3) {
    return rand(pow(10,($length-1)), pow(10,$length)-1);
}

function sskqqname($qq){
$nameurl = "http://r.pengyou.com/fcg-bin/cgi_get_portrait.fcg?uins=".$qq;
$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $nameurl); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
$contents = curl_exec($ch); 
curl_close($ch); 
$info=iconv('GBK', 'UTF-8', $contents);
$array = explode('"', $info);
return $array[5];
}

function get_ssk_ssl_avatar($avatar) {
    //修改头像
    global $wpdb;
    $table_name=$wpdb->prefix."ssk_usermeta";
    $comment = get_comment($comment_id);
    $comment_author_email = trim($comment->comment_author_email);
    //echo "<script>alert('".$comment_author_email."');</script>";
    $checkqq="SELECT `qq` FROM `{$table_name}` WHERE `email` = '{$comment_author_email}'";
    $checkresult = object_array($wpdb->get_results($checkqq));
    //print_r($checkresult);
    $qq=$checkresult['0']['qq'];
    if($qq==""){
       $avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/','<img src="https://secure.gravatar.com/avatar/$1?s=$2" class="avatar avatar-$2" height="$2" width="$2">',$avatar);
    }else{
        //如果wp_ssk_usermeta由当前评论的email 则返回qq 调用qq头像
       $avatar = '<img src="http://q.qlogo.cn/g?b=qq&nk='.$qq.'&s=100&t='.time().generate_code().'" class="avatar avatar-42 photo" height="42" width="42">';
    }
return $avatar;
}
add_filter('get_avatar', 'get_ssk_ssl_avatar');

function wp_insert_qq() {
    global $wpdb;
    $table_name=$wpdb->prefix."ssk_usermeta";
    if(isset($_POST['qq']) && $_POST['qq']!=""){
        $qq=$_POST['qq'];
        $email=$_POST['email'];
        $url=$_POST['url'];
        $checkqq="SELECT * FROM `{$table_name}` WHERE `qq` = {$qq}";
        $checkresult = object_array($wpdb->get_results($checkqq));
        $count=count($checkresult);
        if($count=="0"){
            //无记录        
            $wpdb->insert( $table_name, array( 'qq' => $qq, 'email' => $email, 'url' => $url ) );
        }else{
            //有记录 修改输入框自动返回内容提交评论时直接修改后台记录
            if($email!=$checkresult[0][email]){
                $checkemailresult = object_array($wpdb->get_results("SELECT * FROM `{$table_name}` WHERE `email` = '{$email}'"));
                $countemail=count($checkemailresult);
            //setcookie("update-email-test", $countemail);
                if($countemail==0){
                    //setcookie("update-email-test", $email);
                    $wpdb->update( $table_name, array( 'email' => $email, 'emailcheck' => '0' ), array( 'qq' => $qq ) );
                }else{
                    //setcookie("update-email-test", "USED!!");
                }
            }else{}
            if($url!=$checkresult[0][url]){
                $checkurlresult = object_array($wpdb->get_results("SELECT * FROM `{$table_name}` WHERE `url` = {$url}"));
                $counturl=count($checkurlresult);
                if($counturl==0){
                    $wpdb->update( $table_name, array( 'url' => $url ), array( 'qq' => $qq ) );
                }else{
                    echo "<script>alert('您修改的站点已被占用！');</script>";
                }
            }else{}
            //setcookie( 'comment_author_qq_' . COOKIEHASH, $qq, time()+30000000 );
        }
    }else{
        //$qq='';
    }
}
add_action('wp_insert_comment','wp_insert_qq',10,2);

function ssk_get_http_response_code($theURL) {
	@$headers = get_headers($theURL);
	return substr($headers[0], 9, 3);
}

function ssk_check_version_setup_schedule() {
	if ( ! wp_next_scheduled( 'ssk_check_version_daily_event' ) ) {
		wp_schedule_event( '1193875200', 'daily', 'ssk_check_version_daily_event');
	}
}
add_action( 'wp', 'ssk_check_version_setup_schedule' );

function ssk_check_version_do_this_daily() {
	if(ssk_get_http_response_code('http://ssk.91txh.com/sskupdate/?name=sskqquser&from='.site_url())=='200'){
		$check = 0;
		$sskVersion = SSK_VER;
		$version = json_decode(wp_remote_retrieve_body(wp_remote_get('http://ssk.91txh.com/sskupdate/?name=sskqquser&from='.site_url())),true);
		if ( $version["sskqquser"] != $sskVersion && !empty($version["sskqquser"]) ) {$check = $version["sskqquser"];}
		update_option('sskqquser_upgrade',$check);
	}
}
add_action( 'ssk_check_version_daily_event', 'ssk_check_version_do_this_daily' );

function ssk_update_alert_callback(){
	$ssk_upgrade = get_option('sskqquser_upgrade',0);
	if($ssk_upgrade&&$ssk_upgrade!=SSK_VER){
		echo '<div class="updated fade"><p>'.sprintf(__('QQ信息自动获取系统已更新至<a color="red">%1$s</a>(当前%2$s)，请访问<a href="http://ssk.91txh.com/381" target="_blank">我的那些事 QQ信息自动获取系统专页</a>查看！','ssk'),$ssk_upgrade,SSK_VER).'</p></div>';
	}
}
add_action( 'admin_notices', 'ssk_update_alert_callback' );
?>